# Collapsible Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/Fayzulla2022/pen/ZEZmMbP/e7498d824f4e0b0c04d4f8597006ffd6](https://codepen.io/Fayzulla2022/pen/ZEZmMbP/e7498d824f4e0b0c04d4f8597006ffd6).

A timeline with animated collapsible descriptions for each item.

Source for Unix facts: [Wikipedia](https://en.wikipedia.org/wiki/Unix_time).